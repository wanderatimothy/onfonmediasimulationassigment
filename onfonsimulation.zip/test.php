<?php

// function prime_number($var)
// {
//     $check = 0;
//     if ($var != 1) {
//         for ($i = 2; $i < $var / 2; ++$i) {
//             if (($var % $i) == 0) {
//                 $check = 1;
//                 break;
//             }
//         }
//         if ($check == 0) {
//             return true;
//         } else {
//             return false;
//         }
//     } else {
//         return false;
//     }
// }




// echo prime_number(11);
// die;
